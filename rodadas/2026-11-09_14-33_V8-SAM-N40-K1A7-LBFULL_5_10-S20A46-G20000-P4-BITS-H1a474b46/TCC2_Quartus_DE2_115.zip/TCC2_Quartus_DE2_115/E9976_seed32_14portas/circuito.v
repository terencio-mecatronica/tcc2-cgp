`default_nettype none
module circuito(input wire A,B,C,D, output wire a,b,c,d,e,f,g);
wire n6, n8, n9, n11, n13, n14, n17, n18, n22, n23, n27, n28, n36, n42;
assign n6 = ~(D | C);
assign n8 = ~(A ^ C);
assign n9 = (n6 & B);
assign n11 = (D & B);
assign n13 = ~(D | n9);
assign n14 = ~(n11 ^ n8);
assign n17 = (n14 | n13);
assign n18 = (n6 | A);
assign n22 = (n17 & B);
assign n23 = (n9 ^ n14);
assign n27 = (n18 | n22);
assign n28 = ~n22;
assign n36 = (D | n27);
assign n42 = (n17 | C);
assign a = n42;
assign b = n28;
assign c = n36;
assign d = n17;
assign e = n13;
assign f = n27;
assign g = n23;
endmodule
`default_nettype wire

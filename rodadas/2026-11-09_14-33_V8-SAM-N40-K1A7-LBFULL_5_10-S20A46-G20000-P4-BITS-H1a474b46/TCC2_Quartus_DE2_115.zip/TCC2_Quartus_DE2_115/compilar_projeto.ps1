param([Parameter(Mandatory=$true)][string]$PastaProjeto)
$ErrorActionPreference = 'Stop'
if (-not (Get-Command quartus_sh -ErrorAction SilentlyContinue)) { throw 'quartus_sh nao esta no PATH. Abra o Quartus e compile pela interface ou configure o PATH.' }
$destino = (Resolve-Path -LiteralPath $PastaProjeto).Path
if (-not (Test-Path -LiteralPath (Join-Path $destino 'decoder.qpf'))) { throw 'Escolha a pasta de UM projeto, contendo decoder.qpf.' }
Push-Location $destino
try { & quartus_sh --flow compile decoder 2>&1 | Tee-Object -FilePath compilacao_quartus.txt; if ($LASTEXITCODE -ne 0) { throw 'A compilacao falhou. Consulte compilacao_quartus.txt.' } }
finally { Pop-Location }

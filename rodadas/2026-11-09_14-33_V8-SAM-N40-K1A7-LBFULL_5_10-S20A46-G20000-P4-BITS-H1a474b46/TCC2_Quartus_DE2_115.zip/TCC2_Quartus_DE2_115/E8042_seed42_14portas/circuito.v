`default_nettype none
module circuito(input wire A,B,C,D, output wire a,b,c,d,e,f,g);
wire n4, n6, n7, n8, n12, n16, n21, n22, n27, n31, n33, n34, n39, n40;
assign n4 = ~(B & D);
assign n6 = (C | A);
assign n7 = ~(n6 ^ n4);
assign n8 = ~(B | D);
assign n12 = (n8 | n7);
assign n16 = ~(n12 & n12);
assign n21 = ~(C & n8);
assign n22 = ~(D | n7);
assign n27 = ~(n22 ^ A);
assign n31 = (n12 | C);
assign n33 = ~(n22 ^ n16);
assign n34 = ~(B & n7);
assign n39 = ~(n16 | D);
assign n40 = ~(n27 & n34);
assign a = n31;
assign b = n34;
assign c = n21;
assign d = n12;
assign e = n39;
assign f = n40;
assign g = n33;
endmodule
`default_nettype wire

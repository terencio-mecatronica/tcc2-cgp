`default_nettype none
module circuito(input wire A,B,C,D, output wire a,b,c,d,e,f,g);
wire n4, n5, n9, n10, n11, n12, n14, n16, n19, n20, n27, n30, n31, n34;
assign n4 = ~(B | A);
assign n5 = (C & n4);
assign n9 = (C ^ n4);
assign n10 = ~(n9 | D);
assign n11 = ~(n10 & B);
assign n12 = (n9 & D);
assign n14 = (n11 ^ D);
assign n16 = (n12 ^ n11);
assign n19 = ~(B & n16);
assign n20 = ~(n4 & n10);
assign n27 = ~(n16 | C);
assign n30 = ~(n27 | n27);
assign n31 = ~(n19 & n9);
assign n34 = ~(n12 | n5);
assign a = n30;
assign b = n19;
assign c = n20;
assign d = n16;
assign e = n14;
assign f = n34;
assign g = n31;
endmodule
`default_nettype wire

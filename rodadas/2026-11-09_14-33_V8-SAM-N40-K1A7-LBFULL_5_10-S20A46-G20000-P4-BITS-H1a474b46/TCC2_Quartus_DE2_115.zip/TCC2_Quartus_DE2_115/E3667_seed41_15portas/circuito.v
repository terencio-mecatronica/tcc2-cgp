`default_nettype none
module circuito(input wire A,B,C,D, output wire a,b,c,d,e,f,g);
wire n4, n5, n10, n12, n13, n16, n18, n19, n26, n27, n31, n34, n35, n41, n43;
assign n4 = (B | A);
assign n5 = ~(n4 ^ C);
assign n10 = (D | C);
assign n12 = ~(C ^ D);
assign n13 = ~(n4 ^ n12);
assign n16 = (D | B);
assign n18 = (D | n13);
assign n19 = (n16 | n12);
assign n26 = ~(n16 & n18);
assign n27 = (n13 | n12);
assign n31 = ~(n5 & n27);
assign n34 = ~(n13 & n16);
assign n35 = ~(n27 & n10);
assign n41 = (n34 | C);
assign n43 = (A | n27);
assign a = n41;
assign b = n43;
assign c = n19;
assign d = n34;
assign e = n26;
assign f = n35;
assign g = n31;
endmodule
`default_nettype wire

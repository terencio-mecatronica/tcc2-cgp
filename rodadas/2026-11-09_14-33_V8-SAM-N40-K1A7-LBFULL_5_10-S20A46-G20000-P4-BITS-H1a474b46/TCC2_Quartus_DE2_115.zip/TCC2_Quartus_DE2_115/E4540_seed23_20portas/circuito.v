`default_nettype none
module circuito(input wire A,B,C,D, output wire a,b,c,d,e,f,g);
wire n4, n5, n6, n8, n9, n11, n12, n13, n15, n17, n19, n23, n25, n26, n30, n31, n32, n33, n34, n41;
assign n4 = (C ^ D);
assign n5 = ~(C & B);
assign n6 = ~(n4 ^ A);
assign n8 = ~(n5 & n4);
assign n9 = ~(n5 ^ n6);
assign n11 = (D ^ n9);
assign n12 = ~(n4 & n11);
assign n13 = ~(n4 & B);
assign n15 = (B ^ n12);
assign n17 = (n8 ^ D);
assign n19 = ~(n17 ^ n6);
assign n23 = ~(n15 & n15);
assign n25 = ~(n23 & n5);
assign n26 = ~(n23 & n19);
assign n30 = ~(n13 ^ n12);
assign n31 = (n26 ^ D);
assign n32 = ~(n30 ^ n17);
assign n33 = ~(n11 & n19);
assign n34 = (n33 ^ n23);
assign n41 = ~(n19 & C);
assign a = n25;
assign b = n13;
assign c = n41;
assign d = n15;
assign e = n31;
assign f = n32;
assign g = n34;
endmodule
`default_nettype wire

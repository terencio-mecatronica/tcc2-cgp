`default_nettype none
module circuito(input wire A,B,C,D, output wire a,b,c,d,e,f,g);
wire n4, n5, n7, n9, n13, n14, n15, n16, n20, n21, n23, n36, n39, n40;
assign n4 = ~(B & D);
assign n5 = ~(n4 & B);
assign n7 = ~(n5 & C);
assign n9 = ~(C | n5);
assign n13 = ~(A | B);
assign n14 = ~(D | n9);
assign n15 = (n7 ^ n13);
assign n16 = (n15 ^ n9);
assign n20 = ~(B & n16);
assign n21 = ~(n13 & D);
assign n23 = (n14 | n16);
assign n36 = (n21 & n7);
assign n39 = (n23 | C);
assign n40 = (D | n36);
assign a = n39;
assign b = n20;
assign c = n40;
assign d = n23;
assign e = n14;
assign f = n36;
assign g = n15;
endmodule
`default_nettype wire

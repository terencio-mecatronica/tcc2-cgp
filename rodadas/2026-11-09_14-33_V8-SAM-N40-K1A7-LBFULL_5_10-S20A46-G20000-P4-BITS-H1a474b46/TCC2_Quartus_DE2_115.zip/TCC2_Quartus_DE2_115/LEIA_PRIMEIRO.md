# TCC2 — validação na Terasic DE2-115

## Material necessário

DE2-115 com fonte do fabricante; cabo USB para o conector USB-Blaster da placa; computador com Quartus Prime Lite ou Standard com suporte ao Cyclone IV E e driver USB-Blaster. Use as chaves e o display da própria placa. Não são necessários componentes externos para este ensaio combinacional.

## O que já foi verificado

Os 15 projetos deste pacote passaram em simulação com Icarus Verilog 11.0: núcleo e adaptação para o display conferem as 10 entradas BCD válidas, 70 bits de saída em cada camada. A compilação no Quartus e o ensaio físico estão PENDENTES. Simulação HDL não comprova pinagem, alimentação ou funcionamento físico.

Comece por `E8274_seed31_14portas` (SAM atual, profundidade 5). Depois teste `HIST_DIRETA_E1563_seed43_13portas` (recorde anterior, mutação direta), `E3667_seed41_15portas` (SAM atual, profundidade 4) e `E4540_seed23_20portas` (representante da moda atual). Consulte a seleção para o nome exato. Os demais empates de 14 portas foram preservados, além de um representante histórico de 18 portas. A repetição da contagem não significa que sejam circuitos idênticos.

## Antes de compilar

1. Confira o modelo da placa: DE2-115. O projeto usa EP4CE115F29C7; confira o código do FPGA da sua unidade antes de manter essa seleção.
2. Consulte o manual DE2-115, seções de chaves, displays e HSMC. Os pinos usados foram transcritos das tabelas 4-2 e 4-4.
3. O QSF foi preparado para JP7 em 2,5 V (jumper nos pinos 5 e 6, padrão indicado no manual). Confira o jumper com a placa desligada. Os pinos HEX0[0..2] são de 2,5 V; as chaves e HEX0[3..6] dependem do JP7. Se sua placa tiver outra configuração, ajuste os padrões dos respectivos bancos no Quartus conforme o manual. Não altere JP6 para este projeto.

## Passo a passo no Quartus

1. Extraia o ZIP inteiro em uma pasta local. Entre na pasta do circuito escolhido e abra `decoder.qpf` pelo Quartus. Não abra todas as pastas como um único projeto.
2. Em Assignments > Device, confira Cyclone IV E / EP4CE115F29C7. O top-level é `top_de2_115`. Somente `circuito.v` e `top_de2_115.v` participam da síntese. `tb.v` é exclusivo da simulação.
3. Em Assignments > Pin Planner, confira SW[3:0] e HEX0[6:0] com a tabela abaixo. Não é necessário associar clock: o circuito é combinacional.
4. Execute Processing > Start Compilation. Salve os relatórios, incluindo erros e avisos. Avisos de ausência de clock/SDC não fornecem medida de atraso: este ensaio não apresenta análise temporal.
5. Ligue a placa com a fonte adequada, conecte o cabo USB-Blaster e selecione o modo JTAG. Abra Tools > Programmer > Hardware Setup e escolha USB-Blaster. Use Auto Detect se necessário.
6. Adicione `output_files/decoder.sof`, marque Program/Configure e clique Start. Esta é programação volátil via JTAG; não é necessário gravar a memória de configuração.
7. Aplique SW[3:0] de 0000 até 1001, observando HEX0. SW3 é A (peso 8), SW2 é B (4), SW1 é C (2), SW0 é D (1). Cada padrão deve mostrar o dígito correspondente. Aguarde as chaves estabilizarem; comutação mecânica não é ensaio de atraso.
8. Preencha `registro_ensaio.csv` e preserve foto/vídeo identificado e relatórios do projeto. Para cada circuito, registre versão do Quartus, dispositivo, recursos do Compilation Report, resultado dos dez dígitos e eventuais diferenças. Só então marque o teste físico como aprovado.

| Sinal | Pino | Sinal | Pino |
|---|---|---|---|
| SW[0] | AB28 | HEX0[0] (a) | G18 |
| SW[1] | AC28 | HEX0[1] (b) | F22 |
| SW[2] | AC27 | HEX0[2] (c) | E17 |
| SW[3] | AD27 | HEX0[3] (d) | L26 |
| | | HEX0[4] (e) | L25 |
| | | HEX0[5] (f) | J22 |
| | | HEX0[6] (g) | H22 |

O núcleo usa 1 para segmento aceso; a placa usa 0. A linha `assign HEX0 = ~{g,f,e,d,c,b,a};` faz a inversão e mantém HEX0[0]=a. Não inverta novamente no Pin Planner.

## Domínio e comparação

BCD 10–15 é don't care e não integra os critérios de aprovação. Os desenhos de 6 e 9 são os da tabela do projeto (a aceso no 6; d aceso no 9). A contagem de portas CGP não é a contagem de elementos lógicos do FPGA. O Quartus pode reescrever a lógica e mapear circuitos distintos em recursos semelhantes. Registre recursos pós-compilação sem convertê-los em “portas CGP”. Área física, consumo e atraso não são estimados neste pacote.

## Repetir a simulação

Com Icarus instalado, dentro de uma pasta de projeto:

```powershell
iverilog -g2012 -s tb -o simulacao circuito.v top_de2_115.v tb.v
vvp simulacao
```

O testbench compara núcleo e wrapper separadamente e termina com erro se houver divergência. Os arquivos `simulacao_hdl.txt` registram a execução já realizada, e `validacao.json` mantém origem, seed e SHA-256 do núcleo.

Referência do fabricante: https://www.terasic.com.tw/attachment/archive/502/DE2_115_User_manual.pdf

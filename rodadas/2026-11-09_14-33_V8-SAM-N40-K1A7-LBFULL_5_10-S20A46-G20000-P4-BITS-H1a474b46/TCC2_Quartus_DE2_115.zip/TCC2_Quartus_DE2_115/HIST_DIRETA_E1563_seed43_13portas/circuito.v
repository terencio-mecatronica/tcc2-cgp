// SINGLE_ATIVO_DIRETO | E1563 | seed 43 | 13 portas
// BCD: A=8, B=4, C=2, D=1; a..g: 1 acende. 10..15: don't care no protocolo principal.

`default_nettype none
module circuito(input wire A, B, C, D, output wire a, b, c, d, e, f, g);
wire n4, n6, n9, n13, n14, n16, n18, n20, n24, n28, n29, n35, n41;
assign n4 = (B ^ C);
assign n6 = ~(A | n4);
assign n9 = (n6 ^ D);
assign n13 = ~(C | n6);
assign n14 = (n13 & n4);
assign n16 = ~(n14 | D);
assign n18 = (n9 | n16);
assign n20 = (C | n18);
assign n24 = ~(B & n18);
assign n28 = (n6 & n18);
assign n29 = (n28 | n13);
assign n35 = ~(n4 & n16);
assign n41 = ~(n24 & n6);
assign a = n20;
assign b = n24;
assign c = n35;
assign d = n18;
assign e = n16;
assign f = n29;
assign g = n41;
endmodule
`default_nettype wire

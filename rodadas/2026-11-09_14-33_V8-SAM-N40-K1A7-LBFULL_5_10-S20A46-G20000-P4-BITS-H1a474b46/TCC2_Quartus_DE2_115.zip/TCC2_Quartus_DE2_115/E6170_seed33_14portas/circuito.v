`default_nettype none
module circuito(input wire A,B,C,D, output wire a,b,c,d,e,f,g);
wire n5, n7, n8, n13, n18, n19, n21, n22, n24, n25, n31, n33, n39, n43;
assign n5 = ~(A ^ C);
assign n7 = (B ^ n5);
assign n8 = ~(D & D);
assign n13 = (n5 & D);
assign n18 = ~(n8 ^ n7);
assign n19 = ~(n18 & B);
assign n21 = ~(n19 ^ C);
assign n22 = (B ^ n13);
assign n24 = ~(n21 & n8);
assign n25 = ~(n13 ^ n21);
assign n31 = ~(n19 & n22);
assign n33 = ~(n22 & n5);
assign n39 = ~(n7 & n19);
assign n43 = (n31 & n8);
assign a = n33;
assign b = n19;
assign c = n24;
assign d = n31;
assign e = n43;
assign f = n25;
assign g = n39;
endmodule
`default_nettype wire

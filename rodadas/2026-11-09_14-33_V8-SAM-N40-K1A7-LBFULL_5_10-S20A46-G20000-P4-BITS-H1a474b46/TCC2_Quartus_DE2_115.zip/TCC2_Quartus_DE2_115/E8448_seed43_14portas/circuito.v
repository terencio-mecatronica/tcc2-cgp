`default_nettype none
module circuito(input wire A,B,C,D, output wire a,b,c,d,e,f,g);
wire n4, n5, n6, n7, n9, n11, n12, n13, n15, n18, n28, n35, n37, n40;
assign n4 = ~(C ^ D);
assign n5 = (A ^ B);
assign n6 = ~(n4 | B);
assign n7 = (n4 | n6);
assign n9 = (C & n7);
assign n11 = (n9 ^ n5);
assign n12 = (n4 | n11);
assign n13 = (n4 ^ n5);
assign n15 = (n7 & B);
assign n18 = ~(n15 | D);
assign n28 = (n9 ^ n12);
assign n35 = (n18 | n13);
assign n37 = (n9 | n35);
assign n40 = (D | n28);
assign a = n37;
assign b = n7;
assign c = n40;
assign d = n35;
assign e = n18;
assign f = n28;
assign g = n11;
endmodule
`default_nettype wire

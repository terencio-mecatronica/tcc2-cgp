`default_nettype none
module circuito(input wire A,B,C,D, output wire a,b,c,d,e,f,g);
wire n4, n5, n6, n8, n10, n11, n15, n16, n20, n25, n28, n30, n32, n36;
assign n4 = ~(A | C);
assign n5 = ~(n4 ^ B);
assign n6 = ~(D ^ n4);
assign n8 = ~(n5 | A);
assign n10 = ~(n8 & n6);
assign n11 = ~(n6 & B);
assign n15 = ~(n10 & n11);
assign n16 = ~(n8 & n11);
assign n20 = (n10 ^ C);
assign n25 = ~(n15 ^ B);
assign n28 = (n25 | C);
assign n30 = (n20 | D);
assign n32 = ~(n28 ^ D);
assign n36 = ~(n32 | D);
assign a = n28;
assign b = n11;
assign c = n30;
assign d = n25;
assign e = n36;
assign f = n20;
assign g = n16;
endmodule
`default_nettype wire

// SINGLE_ATIVO_DIRETO | E343 | seed 38 | 18 portas
// BCD: A=8, B=4, C=2, D=1; a..g: 1 acende. 10..15: don't care no protocolo principal.

`default_nettype none
module circuito(input wire A, B, C, D, output wire a, b, c, d, e, f, g);
wire n4, n8, n9, n10, n11, n15, n18, n20, n21, n22, n23, n24, n26, n27, n28, n29, n34, n42;
assign n4 = ~(D | B);
assign n8 = ~(C & D);
assign n9 = ~(A | B);
assign n10 = ~(D | C);
assign n11 = ~n9;
assign n15 = (n11 & n8);
assign n18 = ~(n15 | n10);
assign n20 = ~n15;
assign n21 = ~(C & n9);
assign n22 = ~(n20 | n10);
assign n23 = ~(n20 & n21);
assign n24 = ~(n22 & B);
assign n26 = ~(n22 | n4);
assign n27 = ~(C & n4);
assign n28 = ~(n26 | D);
assign n29 = ~(n21 & n26);
assign n34 = ~n18;
assign n42 = ~(n26 & n8);
assign a = n42;
assign b = n24;
assign c = n27;
assign d = n29;
assign e = n28;
assign f = n34;
assign g = n23;
endmodule
`default_nettype wire

`default_nettype none
module top_de2_115(input wire [3:0] SW, output wire [6:0] HEX0);
wire a,b,c,d,e,f,g;
circuito dut(.A(SW[3]),.B(SW[2]),.C(SW[1]),.D(SW[0]),.a(a),.b(b),.c(c),.d(d),.e(e),.f(f),.g(g));
// HEX0[0]=a; display da DE2-115 ativo em nivel baixo.
assign HEX0 = ~{g,f,e,d,c,b,a};
endmodule
`default_nettype wire

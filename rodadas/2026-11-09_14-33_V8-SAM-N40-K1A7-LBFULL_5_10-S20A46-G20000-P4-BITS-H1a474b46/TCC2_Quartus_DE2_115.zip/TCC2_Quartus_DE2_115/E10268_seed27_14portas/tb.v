`timescale 1ns/1ps
module tb;
reg [3:0] SW; wire [6:0] HEX0; wire a,b,c,d,e,f,g;
top_de2_115 board(.SW(SW),.HEX0(HEX0));
circuito core(.A(SW[3]),.B(SW[2]),.C(SW[1]),.D(SW[0]),.a(a),.b(b),.c(c),.d(d),.e(e),.f(f),.g(g));
initial begin
SW=4'd0; #10;
if ({a,b,c,d,e,f,g} !== 7'b1111110) $fatal(1,"core: BCD 0");
if (HEX0 !== ~7'b0111111) $fatal(1,"wrapper: BCD 0");
SW=4'd1; #10;
if ({a,b,c,d,e,f,g} !== 7'b0110000) $fatal(1,"core: BCD 1");
if (HEX0 !== ~7'b0000110) $fatal(1,"wrapper: BCD 1");
SW=4'd2; #10;
if ({a,b,c,d,e,f,g} !== 7'b1101101) $fatal(1,"core: BCD 2");
if (HEX0 !== ~7'b1011011) $fatal(1,"wrapper: BCD 2");
SW=4'd3; #10;
if ({a,b,c,d,e,f,g} !== 7'b1111001) $fatal(1,"core: BCD 3");
if (HEX0 !== ~7'b1001111) $fatal(1,"wrapper: BCD 3");
SW=4'd4; #10;
if ({a,b,c,d,e,f,g} !== 7'b0110011) $fatal(1,"core: BCD 4");
if (HEX0 !== ~7'b1100110) $fatal(1,"wrapper: BCD 4");
SW=4'd5; #10;
if ({a,b,c,d,e,f,g} !== 7'b1011011) $fatal(1,"core: BCD 5");
if (HEX0 !== ~7'b1101101) $fatal(1,"wrapper: BCD 5");
SW=4'd6; #10;
if ({a,b,c,d,e,f,g} !== 7'b1011111) $fatal(1,"core: BCD 6");
if (HEX0 !== ~7'b1111101) $fatal(1,"wrapper: BCD 6");
SW=4'd7; #10;
if ({a,b,c,d,e,f,g} !== 7'b1110000) $fatal(1,"core: BCD 7");
if (HEX0 !== ~7'b0000111) $fatal(1,"wrapper: BCD 7");
SW=4'd8; #10;
if ({a,b,c,d,e,f,g} !== 7'b1111111) $fatal(1,"core: BCD 8");
if (HEX0 !== ~7'b1111111) $fatal(1,"wrapper: BCD 8");
SW=4'd9; #10;
if ({a,b,c,d,e,f,g} !== 7'b1111011) $fatal(1,"core: BCD 9");
if (HEX0 !== ~7'b1101111) $fatal(1,"wrapper: BCD 9");
$display("PASS: core e wrapper, 10 entradas / 70 bits cada; BCD 10-15 fora da especificacao");
$finish; end endmodule

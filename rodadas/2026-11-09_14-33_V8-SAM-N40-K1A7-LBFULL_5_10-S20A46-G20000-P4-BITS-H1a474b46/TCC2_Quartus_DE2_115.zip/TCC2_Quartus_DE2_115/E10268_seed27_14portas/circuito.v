`default_nettype none
module circuito(input wire A,B,C,D, output wire a,b,c,d,e,f,g);
wire n5, n6, n7, n10, n12, n13, n16, n17, n19, n20, n26, n29, n30, n31;
assign n5 = ~(C ^ B);
assign n6 = (D ^ C);
assign n7 = (B & n6);
assign n10 = ~(A | n7);
assign n12 = ~(n6 & B);
assign n13 = ~(n5 & n10);
assign n16 = (D | n6);
assign n17 = ~(n13 & n10);
assign n19 = ~(n10 & n16);
assign n20 = (n12 & B);
assign n26 = ~(n19 ^ n17);
assign n29 = (n19 | D);
assign n30 = ~(n20 | D);
assign n31 = (n26 | C);
assign a = n31;
assign b = n12;
assign c = n29;
assign d = n26;
assign e = n30;
assign f = n19;
assign g = n13;
endmodule
`default_nettype wire

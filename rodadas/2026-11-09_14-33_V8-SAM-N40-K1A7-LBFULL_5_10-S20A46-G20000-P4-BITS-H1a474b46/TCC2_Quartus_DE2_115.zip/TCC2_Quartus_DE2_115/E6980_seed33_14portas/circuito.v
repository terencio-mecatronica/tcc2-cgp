`default_nettype none
module circuito(input wire A,B,C,D, output wire a,b,c,d,e,f,g);
wire n4, n6, n7, n9, n10, n13, n15, n20, n22, n23, n29, n30, n34, n37;
assign n4 = (A | C);
assign n6 = (n4 ^ B);
assign n7 = ~(n6 ^ D);
assign n9 = ~(n7 & B);
assign n10 = (D | C);
assign n13 = (n4 | n7);
assign n15 = (n10 ^ D);
assign n20 = ~(n9 & n10);
assign n22 = (D | n20);
assign n23 = (D | n13);
assign n29 = (A | n20);
assign n30 = (n23 ^ D);
assign n34 = (n15 | n6);
assign n37 = (n30 | n7);
assign a = n13;
assign b = n9;
assign c = n22;
assign d = n37;
assign e = n30;
assign f = n29;
assign g = n34;
endmodule
`default_nettype wire

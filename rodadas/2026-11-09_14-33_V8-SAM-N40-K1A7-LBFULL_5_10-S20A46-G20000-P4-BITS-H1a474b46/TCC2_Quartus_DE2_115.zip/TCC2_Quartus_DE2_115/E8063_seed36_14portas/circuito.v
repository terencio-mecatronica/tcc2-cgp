`default_nettype none
module circuito(input wire A,B,C,D, output wire a,b,c,d,e,f,g);
wire n4, n5, n6, n8, n10, n13, n16, n17, n20, n21, n22, n23, n27, n28;
assign n4 = (A | C);
assign n5 = ~(n4 ^ B);
assign n6 = ~(D | D);
assign n8 = ~(n4 & n6);
assign n10 = ~(n8 & n5);
assign n13 = (n8 & n10);
assign n16 = ~(D | n13);
assign n17 = ~(n13 ^ D);
assign n20 = ~(n17 ^ B);
assign n21 = (C | n17);
assign n22 = (n20 | C);
assign n23 = ~(n20 & B);
assign n27 = ~(n23 & n22);
assign n28 = (D | n27);
assign a = n21;
assign b = n23;
assign c = n28;
assign d = n17;
assign e = n16;
assign f = n27;
assign g = n10;
endmodule
`default_nettype wire

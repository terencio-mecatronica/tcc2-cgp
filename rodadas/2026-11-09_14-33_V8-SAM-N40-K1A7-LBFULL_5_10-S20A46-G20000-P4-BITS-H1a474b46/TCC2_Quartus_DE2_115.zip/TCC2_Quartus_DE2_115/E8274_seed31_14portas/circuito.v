`default_nettype none
module circuito(input wire A,B,C,D, output wire a,b,c,d,e,f,g);
wire n4, n5, n7, n9, n11, n13, n14, n16, n17, n19, n20, n28, n31, n32;
assign n4 = (C ^ A);
assign n5 = ~(D & D);
assign n7 = ~(n4 & n5);
assign n9 = (n4 ^ B);
assign n11 = ~(n7 & n9);
assign n13 = (n9 | n5);
assign n14 = (n11 & n5);
assign n16 = ~(C & n9);
assign n17 = (D ^ n11);
assign n19 = (n13 & n16);
assign n20 = (n7 | n19);
assign n28 = ~(n17 & B);
assign n31 = (n11 ^ n7);
assign n32 = (n4 | n17);
assign a = n32;
assign b = n28;
assign c = n20;
assign d = n17;
assign e = n14;
assign f = n19;
assign g = n31;
endmodule
`default_nettype wire

# Revisão de análise do TCC2 — 10/11/2026

Esta é uma versão para revisão do autor e do orientador. O título e os nomes seguem a apresentação do TCC1. O histórico teórico anterior foi preservado e as seções incompletas foram desenvolvidas. Foram redigidos introdução, metodologia, resultados, conclusão e resumos, com gráficos produzidos a partir dos resultados reais.

Fonte principal: compartilhamento_v8(2).zip; CSV original SHA-256 750710cbee89084f666458c379b9d3adf4680b2f6033531268b3b7341c0c5caf. Apenas SAM na rodada principal. A comparação histórica usa 1.728 casos comuns; não somar esses casos à rodada como novas réplicas.

Pendências: execução no Quartus e na placa; anexar relatórios e evidências. A referência de Almeida et al. (2026) foi transcrita do TCC1 e deve ter os metadados dos anais conferidos antes da entrega. As contagens históricas de 15 e 22 portas são referências contextuais, sem inventar netlists. Não há resultado novo de área física ou atraso. A norma e a formatação institucional devem ser conferidas conforme os arquivos de orientação já presentes neste projeto. Ficha catalográfica e aprovação foram desativadas na prévia para não apresentar campos fictícios; seus fontes foram mantidos.

Overleaf: crie uma cópia do projeto, envie o ZIP e selecione main.tex, pdfLaTeX e BibTeX. Compilação local: latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex.

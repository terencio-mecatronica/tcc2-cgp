# Análise consolidada — novembro de 2026

Esta revisão desenvolve a metodologia, os resultados e a conclusão a partir das 10.287 execuções SAM, com comparação histórica e 15 projetos aprovados em simulação HDL. A compilação no Quartus e o teste físico permanecem pendentes. Leia `CONSOLIDACAO_2026_11_10.md` antes de editar ou entregar.

## Versão revisada em comparação com o modelo institucional de dez/2023

Leia `CONFERENCIA_MODELO_IFJF.md` para as diferenças e decisões de formatação, inclusive a ressalva obrigatória sobre fontes e normas.

# TCC2 - CGP | Projeto para Overleaf gratuito (versao corrigida)

Esta versao foi feita para resolver o aviso **"Your project needs more compile time"**. Ela usa `pdfLaTeX` + **BibTeX** (`abntex2cite`) em vez de `XeLaTeX` + `Biber` (`biblatex-abnt`).

## Importar sem misturar arquivos

1. No Overleaf, escolha **New Project > Upload Project**.
2. Envie o ZIP desta versao, criando **um projeto novo**, em vez de sobrepor arquivos do projeto antigo.
3. Abra **Settings/Project Settings** e configure **Compiler: pdfLaTeX** e **Main document: main.tex**.
4. Clique em **Recompile**. Quando necessario, use **Recompile from scratch** para apagar arquivos auxiliares de compilacoes antigas.
5. O `main.tex` desta versao comeca com o comentario `Overleaf (free): Compiler=pdfLaTeX` e NAO tem comandos `\addbibresource` nem `\printbibliography`.

**Nota:** este projeto nao utiliza XeLaTeX. O nome do ZIP e diferente do projeto anterior.

## O que mudar em seguida

- `dados-do-trabalho.tex`: nome do autor, titulo, orientador, curso e ano.
- `secoes/01-introducao.tex`: texto da introducao, objetivo geral e objetivos especificos.
- `secoes/02-aportes-teoricos.tex` a `05-conclusao.tex`: os demais capitulos.
- `referencias.bib`: fichas bibliograficas, em sintaxe BibTeX.

### Como citar

- Narrativa: `\citeonline{miller2011cgp}` (ex.: Miller (2011)).
- Entre parenteses: `\cite{miller2011cgp}`.
- Referencias: sao geradas automaticamente pelo comando `\bibliography{referencias}` no fim de `main.tex`.

Nao use `\textcite`, `\parencite`, `\addbibresource` ou `\printbibliography`: eles pertencem a configuracao anterior com biblatex.

## Validacao realizada

Teste local: `latexmk -pdf` com compilacao completa (incluindo BibTeX), gerando 13 paginas em aproximadamente 5 segundos em um ambiente TeX Live local. Isso **nao garante** o mesmo tempo nos servidores do Overleaf, mas diminui sensivelmente o custo da compilacao. Nao envie PDFs ja compilados dentro do ZIP.

## ABNT

Baseado na organizacao do modelo Word do IF Sudeste MG - campus Juiz de Fora (dezembro de 2023). A conformidade com as normas atuais e a adequacao ao modelo institucional continuam sujeitas a revisao. A familia tipografica NewTX e semelhante a Times, mas nao e Times New Roman, que e uma das fontes previstas no documento institucional.

### Caso ainda haja tempo excedido

Confirme que esta no projeto novo e `pdfLaTeX` esta selecionado. Use **Recompile from scratch** e, se ainda falhar, envie a captura de **Logs** e a linha de status do compilador. Nao e necessario comprar um plano pago apenas por este alerta sem esgotarmos as alternativas tecnicas.

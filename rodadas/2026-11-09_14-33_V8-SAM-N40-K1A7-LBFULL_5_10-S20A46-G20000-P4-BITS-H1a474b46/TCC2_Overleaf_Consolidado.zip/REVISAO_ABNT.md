# Revisao institucional e normativa pendente

Este template reproduz uma estrutura inicial, nao constitui homologacao formal ABNT. Conferir com a biblioteca/orientador antes da entrega:

- Fonte do corpo (modelo dez/2023 aceita Arial ou Times New Roman; NewTX nao e uma dessas fontes exatas).
- Folha de rosto, folha de aprovacao e ficha catalografica oficial.
- Regras de paginação e posicao do numero de pagina.
- Paragrafo, margens, linhas, capitulos, subtitulos e pontuacao.
- Figuras: tamanho de legendas, fonte da figura, posicionamento, lista de figuras.
- Referencias ABNT NBR 6023:2025, citacoes NBR 10520:2023, resumo NBR 6028:2021, formato NBR 14724:2024.
- O pacote abntex2cite com BibTeX pode requerer adaptacoes para normas recentes; verificar citacoes autor-data e representacao dos organizadores de livros.
- O documento do IF tem instrucoes por vezes divergentes em diferentes paginas (legendas), que devem ser unificadas com a biblioteca.

As seções ainda sao placeholders; nao introduzir resultados ficticios nem dados experimentais nao verificados.

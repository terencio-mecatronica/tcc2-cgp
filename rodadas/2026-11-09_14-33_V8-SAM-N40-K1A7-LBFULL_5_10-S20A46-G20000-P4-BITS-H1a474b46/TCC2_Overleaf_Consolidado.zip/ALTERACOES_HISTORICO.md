# Atualização dos Aportes Teóricos — contexto histórico

Base: TCC2_CGP_Overleaf_IFJF_Revisto.zip (versão revista do template IF Sudeste MG).

## Alterações

- `secoes/02-aportes-teoricos.tex`: inserção da seção **2.1 CONTEXTO HISTÓRICO E EVOLUÇÃO DA PROGRAMAÇÃO GENÉTICA**, com quatro parágrafos de texto-base, usando o tutorial GECCO 2025 fornecido e a publicação de Miller e Thomson (2000).
- Reorganização dos títulos seguintes em 2.2 Fundamentos da CGP, 2.3 Aplicação à síntese de circuitos combinacionais e 2.4 Espaço de busca e mecanismos de exploração, como discutido no TCC2.
- `referencias.bib`: dois registros bibliográficos preliminares (`kalkreuth2025tutorial` e `miller2000cgp`). O livro organizado por Miller (2011) já estava na base.
- Nenhuma alteração nos arquivos de formatação, capa ou introdução.

## Importante

A seção histórica é uma **primeira redação**, ainda sujeita à seleção definitiva de referências e revisão de formulações. As entradas bibliográficas devem ser conferidas na versão final para adequação à ABNT; o template inteiro ainda possui pendências de conformidade documentadas na revisão anterior.

## Importação no Overleaf

- Para criar projeto novo: faça upload do ZIP desta versão como um novo projeto e mantenha `pdfLaTeX`.
- Para manter o projeto atual: substitua apenas `secoes/02-aportes-teoricos.tex` e `referencias.bib` pelos dois arquivos correspondentes deste ZIP.
- Não mexa nas outras partes do projeto; após atualizar, clique em **Recompile**.

# Conferência com o modelo oficial de dezembro de 2023 — Campus Juiz de Fora

Esta versão é uma adaptação funcional para Overleaf, **não** uma certificação formal da biblioteca nem uma conversão idêntica do arquivo Word. Foram confrontados o DOCX de 46 páginas e as capturas do PDF inicial de 13 páginas.

## Reproduzido no projeto

- A4; margens de 3 cm (superior/esquerda) e 2 cm (inferior/direita).
- Texto 12 pt, justificado, entrelinha 1,5, recuo da primeira linha de 1,25 cm, inclusive após títulos.
- Seções primárias em maiúsculas/negrito; secundárias em maiúsculas/normal; terciárias em negrito e quaternárias normais.
- Capítulos na ordem: Introdução; Aportes Teóricos; Materiais e Métodos; Resultados e Discussões; Conclusão.
- Folha de rosto, ficha catalográfica provisória, folha de aprovação, resumo, abstract, sumário, referências.
- Páginas preliminares contadas desde a folha de rosto, números exibidos apenas a partir da introdução.
- Sumário sem pontilhados, com itens secundários sem negrito, à maneira da imagem do modelo Word.
- Espaço simples e alinhamento à esquerda nas referências.
- Figuras: título acima, fonte abaixo (fonte 10), tabelas com `booktabs`, equações numeradas.

## Diferenças e pontos a confirmar antes de entregar

1. **Fonte**: pdfLaTeX usa NewTX/TeX Gyre Termes (semelhante à Times), mas o Word institucional exige Times New Roman ou Arial. Requer aprovação formal da instituição OU uso de XeLaTeX com fonte legalmente disponível para obter correspondência literal. Não distribuir arquivos de fontes comerciais.
2. **Normas atuais**: o modelo de dezembro/2023 faz referências a normas já revistas; confirmar qual interpretação a biblioteca exige em 2026. O estilo BibTeX abntex2cite deve ser checado em casos de citações com 4+ autores e em referências segundo NBR 6023:2025.
3. **Inconsistência do próprio modelo**: tamanho de legenda aparece como 10 e 12 em páginas diferentes; foi escolhido 12 para títulos, 10 para indicação de fonte; confirmar com a biblioteca.
4. **Palavras-chave**: o documento contém orientações conflitantes sobre o ponto final após a última palavra-chave; confirmar e padronizar.
5. **Ficha catalográfica**: substituir o aviso de reserva pelo documento da biblioteca, quando emitido.
6. **Título extenso, membros de banca, agradecimentos, listas e apêndices**: revisar depois de preencher os dados reais e ativar os módulos necessários.
7. **Saída Overleaf**: compilação local conferida; o limite de tempo de computação pode variar no serviço.

## Como abrir

Overleaf → Novo projeto → Carregar ZIP → Compiler: pdfLaTeX → documento principal `main.tex` → Recompile.

A ausência de listas de figuras e de tabelas na prévia é intencional: sem ilustrações/tabelas no corpo do TCC, elas são ocultadas para evitar listas vazias. Habilitar `\mostrarlistastrue` em `configuracoes.tex` quando utilizadas.
